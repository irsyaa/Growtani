<?php 
session_start();
include "../koneksi/config.php";
if(isset($_POST['user']) && isset($_POST['password']) ){
    $user = $_POST['user'];
    $pass = md5($_POST['password']);
    
    $ceklogin = mysqli_query($koneksi, "SELECT * FROM login WHERE ussername = '$user' AND `password` = '$pass'  ");
    $cek = mysqli_num_rows($ceklogin);
    //echo $cek; 
    if($cek == 1){
        $rec = mysqli_fetch_array($ceklogin);
        $_SESSION['user'] = $user;
        

        header("location: ../dasboard2.php");

    }
    else {
        header("location:login.php?err=1;");
    }
}
?>